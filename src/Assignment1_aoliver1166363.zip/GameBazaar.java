public class GameBazaar { 
        public static void main(String [] args) {
            System.out.println("Game Bazaar");
            System.out.println("CEO: John Gnet");
            System.out.println("Created on September 28, 1995 ");
    }
}
