public class LogoDemo { 
    public static void main(String [] args) { 
        System.out.println( "      *******                  ******* ");
        System.out.println( "     ***^^***                  ********");
        System.out.println( "     ***  ***                  **    ** ");
        System.out.println( "     **   ***   GAME           ** O  **");
        System.out.println( "     ***  ***     BAZAAR       **    ** ");
        System.out.println( "     ***||***                  ********");
        System.out.println( "     *||   ||*                 ***   **");
        System.out.println( "     ***||***                  *** 0 **");
        System.out.println( "     ********                  ***   **");
        System.out.println( "     ********                  ******* ");
        System.out.println( "     **** ***                  *******");
           }
} 