public class purchase { 
    public static void main(String [] args) {
        String Daydate = "2";
        String Monthdate = "2";
        String Yeardate = "2021";
        double cost = 38.41;
        String cart = "5 Mario wallpapers";
        System.out.println( "Thanks for shopping at the Game Bazaar. You purchased:");
        System.out.println(cart);
        System.out.println("cost: $");
        System.out.println(cost);
        System.out.println("on:");
        System.out.println(Daydate +"-"+ Monthdate+"-"+  Yeardate);
    }
} 
